### 2015-02-02 v0.0.6

 * Bugfix: removal doesnt't kill line feed

### 2015-02-02 v0.0.5

Animated pseudo typing with abilities:

 * control of typing speed;
 * control of cursor appearance and speed of blinking;
 * callbacks and events for all appropriate actions;
 * animated removal of parts of text after typing.
